//
//  CartView.swift
//  MNAD23-ICT
//
//  Created by Pubudu Mihiranga on 2023-11-12.
//

import SwiftUI

struct CartView: View {
    
    // declare your properties here
    
    var body: some View {
        NavigationStack {
            VStack {
               Text("Cart Page")
            }
            .padding()
        }
    }
    
    private func calculatePurchasedItems(item: ShopItem) -> Double {
        // calculate price for each purchase item
        // price = item price X item quantity
        return 0.0
    }
    
    private func calculateTotal() {
        // calculate total bill value
        // total bill = each item price X each item quantity
        // hint: you need to calculate a new bill every time a user lands on this page;
        // this might be useful to decide when to display the 'Empty Cart' text.
    }
}

#Preview {
    CartView()
}
