//
//  ContentView.swift
//  MNAD23-ICT
//
//  Created by Pubudu Mihiranga on 2023-11-12.
//

import SwiftUI

struct ContentView: View {
    
    // declare your properties here
    
    @State var shopItems = [
        ShopItem(name: "Broccoli", price: 5.00, quantity: 0)
        // complete remaining data
    ]
    
    @State var showCartView = false
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 10) {
                Text("Home Page")
                
                Spacer()
                
                Button("Click Me") {
                    showCartView.toggle()
                }
            }
            .padding()
            .navigationDestination(isPresented: $showCartView) {
                CartView()
            }
        }
    }
}

#Preview {
    ContentView()
}
