//
//  ParcelModel.swift
//  ParcelCost (Starter)
//
//  The stored data. This is deliberately incomplete.
//

import Foundation
import SwiftData

// The allowed service types. An enum prevents spelling mistakes.
enum ParcelType: String, Codable, CaseIterable {
    case personal = "Personal"
    case business = "Business"
}

// The @Model macro tells SwiftData to store this class as a database table.
@Model
class ParcelData: Identifiable {
    var type: ParcelType
    var cost: Double

    // TODO (Experiment 7): add the other properties your History row needs.
    //   Use your answers from Section 7.3 of the specification:
    //   - which values must be stored?   - which one is optional?   - what makes "newest first" possible?
    //   Remember to update init(...) AND the place that creates a ParcelData (CalculateView.saveRecord).

    init(type: ParcelType, cost: Double) {
        self.type = type
        self.cost = cost
    }
}
