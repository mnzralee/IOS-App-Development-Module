//
//  CalculateView.swift
//  ParcelCost (Starter)
//
//  A working but minimal Calculate screen: one input -> one result -> one saved record.
//  Extend it step by step. Run the app after every change.
//

import SwiftUI
import SwiftData

struct CalculateView: View {
    // Access the SwiftData context so we can save records
    @Environment(\.modelContext) private var modelContext

    // @State holds data that can change; changing it re-draws the view
    @State private var weight: Double = 10.0
    @State private var cost: Double = 0.0
    @State private var showResults: Bool = false

    // TODO (Experiment 3): add length, width, height and a computed `volume`
    // TODO (Experiment 5): add the toggle state, insurance amount and a computed `parcelType`
    // TODO (Experiment 6): add state for the "Invalid Input" alert and a computed `inputsAreValid`
    // TIP: should the four measurements be @State or @AppStorage? See Section 3.1 of the spec.

    var body: some View {
        NavigationStack {
            Form {
                // TODO (Experiment 5): "Parcel Setup" section with the Personal/Business toggle,
                //                      and the insurance slider (Business only)

                Section("Dimensions & Weight") {
                    DimensionInput(title: "Weight (kg)", value: $weight)
                    // TODO (Experiment 3): Length, Width, Height rows
                }

                Section {
                    Button(action: calculateCost) {
                        Text("Calculate Cost")
                            .frame(maxWidth: .infinity, alignment: .center)
                            .fontWeight(.semibold)
                    }
                }

                // Only shown once a calculation has succeeded
                if showResults {
                    Section("Results") {
                        HStack {
                            Text("Total Cost").fontWeight(.semibold)
                            Spacer()
                            Text(cost, format: .currency(code: "GBP"))
                                .bold()
                                .foregroundColor(.red)
                        }
                    }
                }
            }
            .navigationTitle("Parcel Cost")
            // TODO (Experiment 6): .alert("Invalid Input", ...) here
        }
    }

    // MARK: - Calculation

    private func calculateCost() {
        // TODO (Experiment 6): guard that the inputs are valid before calculating

        // PLACEHOLDER: not the real pricing rule! Replace it (Experiments 4 and 5).
        let totalCost = placeholderCost()

        cost = totalCost
        showResults = true
        saveRecord(calculatedCost: totalCost)
    }

    // TODO (Experiment 4): replace with calculatePersonalCost() using the rules in Section 4
    // TODO (Experiment 5): add calculateBusinessCost() and choose between them
    private func placeholderCost() -> Double {
        weight * 0.50
    }

    // MARK: - Persistence

    private func saveRecord(calculatedCost: Double) {
        // PLACEHOLDER: always saves as Personal. Fix this in Experiments 5 and 7.
        let newRecord = ParcelData(type: .personal, cost: calculatedCost)

        modelContext.insert(newRecord)
        try? modelContext.save()
    }
}

// A small reusable row: a title on the left and an editable number on the right.
// @Binding connects this subview to the @State (or @AppStorage) property in its parent.
struct DimensionInput: View {
    let title: String
    @Binding var value: Double

    var body: some View {
        HStack {
            Text(title)
            Spacer()
            TextField("0.0", value: $value, format: .number)
                .keyboardType(.decimalPad)
                .multilineTextAlignment(.trailing)
        }
    }
}

#Preview {
    CalculateView()
        .modelContainer(for: ParcelData.self, inMemory: true)
}
