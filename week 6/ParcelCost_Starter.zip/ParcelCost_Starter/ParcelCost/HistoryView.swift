//
//  HistoryView.swift
//  ParcelCost (Starter)
//
//  A bare History list. It shows every saved record, unsorted and unfiltered.
//

import SwiftUI
import SwiftData

struct HistoryView: View {
    // @Query reads ParcelData from the database and keeps the view up to date automatically.
    // TODO (Experiment 8): sort newest first  ->  @Query(sort: ..., order: ...)
    @Query var records: [ParcelData]

    // TODO (Experiment 8): add state for the selected filter (All / Personal / Business)
    // TODO (Experiment 8): add a computed `filteredRecords` and list that instead of `records`

    var body: some View {
        NavigationStack {
            // TODO (Experiment 8): segmented Picker above the list
            List(records) { record in
                // TODO (Experiment 7): replace with a proper row (icon, date, weight, volume, cost, optional insurance)
                HStack {
                    Text(record.type.rawValue)
                    Spacer()
                    Text(record.cost, format: .currency(code: "GBP"))
                }
            }
            .navigationTitle("Parcels History")
        }
    }
}

#Preview {
    HistoryView()
        .modelContainer(for: ParcelData.self, inMemory: true)
}
