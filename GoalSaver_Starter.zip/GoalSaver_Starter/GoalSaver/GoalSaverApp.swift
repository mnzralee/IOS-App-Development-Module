//
//  GoalSaverApp.swift
//  GoalSaver
//
//  Tutorial starter – Week 7 practical preparation.
//

import SwiftUI
import SwiftData

@main
struct GoalSaverApp: App {
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
        // TASK 9 – HINT: Inject your SwiftData model container here so every view can reach it.
        // .modelContainer(...)
        .modelContainer(for: SavingsRecord.self)
    }
}
