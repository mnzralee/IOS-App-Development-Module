import Foundation

struct Movie: Identifiable, Sendable {
    let id: Int
    let title: String
    let releaseYear: Int?
    let rating: Double
    let genre: Genre
    let runtimeMinutes: Int?
    let language: String?

    enum Genre: String, CaseIterable, Sendable {
        case action = "Action"
        case sciFi = "Sci-Fi"
        case drama = "Drama"
        case comedy = "Comedy"
        case unknown = "Unknown"
    }
}
