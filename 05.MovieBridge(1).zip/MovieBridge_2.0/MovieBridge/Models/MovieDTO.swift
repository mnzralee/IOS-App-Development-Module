import Foundation

struct MovieResponseDTO: Decodable, Sendable {
    let results: [MovieDTO]
}

struct MovieDTO: Decodable, Sendable {
    let id: Int
    let title: String
    let releaseDate: String?
    let voteAverage: Double
    let genreIds: [Int]
    let details: DetailsDTO?

    enum CodingKeys: String, CodingKey {
        case id
        case title
        case releaseDate = "release_date"
        case voteAverage = "vote_average"
        case genreIds = "genre_ids"
        case details
    }
}

struct DetailsDTO: Decodable, Sendable {
    let runtime: Int?
    let language: String?
}
