import Foundation

/// TMDB genre IDs that MovieBridge recognises. TMDB publishes ~19; the rest
/// fall through to `.unknown` on purpose (see `mapGenre`).
private enum TMDBGenre {
    static let action = 28
    static let comedy = 35
    static let drama = 18
    static let sciFi = 878
}

extension MovieDTO {
    func toDomain() -> Movie {
        Movie(
            id: id,
            title: title,
            releaseYear: releaseDate.flatMap { Int($0.prefix(4)) },
            rating: voteAverage,
            genre: mapGenre(from: genreIds),
            runtimeMinutes: details?.runtime,
            language: details?.language
        )
    }

    /// The check order IS the priority rule: first match wins.
    /// The Matrix ([28, 878]) is both Action and Sci-Fi; Sci-Fi is checked
    /// first, so it becomes `.sciFi`. Changing the order changes the result.
    private func mapGenre(from ids: [Int]) -> Movie.Genre {
        if ids.contains(TMDBGenre.sciFi) { return .sciFi }
        if ids.contains(TMDBGenre.action) { return .action }
        if ids.contains(TMDBGenre.comedy) { return .comedy }
        if ids.contains(TMDBGenre.drama) { return .drama }
        return .unknown   // deliberate fallback: unrecognised IDs are not an error
    }
}
