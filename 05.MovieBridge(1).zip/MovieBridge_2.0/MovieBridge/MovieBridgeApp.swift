import SwiftUI

@main
struct MovieBridgeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
