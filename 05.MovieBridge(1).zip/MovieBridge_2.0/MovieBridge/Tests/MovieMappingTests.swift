import XCTest
@testable import MovieBridge

final class MovieMappingTests: XCTestCase {

    // MARK: - Decoding test: JSON → DTO
    // "Does the external contract decode?" — this test knows nothing about
    // Movie, Genre, or toDomain(). If it fails, the JSON shape changed or
    // the DTO's CodingKeys are wrong — nothing else.

    func testDecodingProducesExpectedDTO() throws {
        let json = """
        {
          "results": [
            {
              "id": 603,
              "title": "The Matrix",
              "release_date": "1999-03-31",
              "vote_average": 8.7,
              "genre_ids": [28, 878],
              "details": { "runtime": 136, "language": "en" }
            }
          ]
        }
        """

        let data = Data(json.utf8)
        let response = try JSONDecoder().decode(MovieResponseDTO.self, from: data)
        let dto = try XCTUnwrap(response.results.first)

        XCTAssertEqual(dto.id, 603)
        XCTAssertEqual(dto.title, "The Matrix")
        XCTAssertEqual(dto.releaseDate, "1999-03-31")
        XCTAssertEqual(dto.voteAverage, 8.7)
        XCTAssertEqual(dto.genreIds, [28, 878])
        XCTAssertEqual(dto.details?.runtime, 136)
    }

    // MARK: - Mapping test: DTO → Domain
    // "Does the application get the right meaning?" — this test builds a
    // DTO directly, with no JSON in sight. It fails only if toDomain()'s
    // translation rules are wrong — decoding is not involved at all.

    func testMappingProducesExpectedDomainMovie() {
        let dto = MovieDTO(
            id: 603,
            title: "The Matrix",
            releaseDate: "1999-03-31",
            voteAverage: 8.7,
            genreIds: [28, 878],
            details: DetailsDTO(runtime: 136, language: "en")
        )

        let movie = dto.toDomain()

        XCTAssertEqual(movie.title, "The Matrix")
        XCTAssertEqual(movie.releaseYear, 1999)
        XCTAssertEqual(movie.rating, 8.7)
        XCTAssertEqual(movie.runtimeMinutes, 136)
        XCTAssertEqual(movie.language, "en")
    }

    // MARK: - Mapping test: the genre priority rule
    // Isolates the one piece of mapper behaviour most likely to surprise a
    // reader — genreIds [28, 878] resolves to .sciFi, not .action, because
    // the Sci-Fi check runs first in toDomain(). This test exists so that
    // changing that order is a deliberate choice, not an accident.

    func testMappingAppliesGenrePriorityOrder() {
        let dto = MovieDTO(
            id: 603,
            title: "The Matrix",
            releaseDate: "1999-03-31",
            voteAverage: 8.7,
            genreIds: [28, 878], // both Action and Sci-Fi
            details: nil
        )

        XCTAssertEqual(dto.toDomain().genre, .sciFi)
    }

    // MARK: - Mapping test: unrecognised genre falls back silently

    func testMappingFallsBackToUnknownGenre() {
        let dto = MovieDTO(
            id: 999,
            title: "Untagged Film",
            releaseDate: "2020-01-01",
            voteAverage: 5.0,
            genreIds: [99], // not one of the four MovieBridge recognises
            details: nil
        )

        XCTAssertEqual(dto.toDomain().genre, .unknown)
    }
}
