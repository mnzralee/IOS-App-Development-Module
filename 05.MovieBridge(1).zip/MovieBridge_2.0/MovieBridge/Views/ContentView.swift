import SwiftUI

struct ContentView: View {
    @State private var viewModel: MovieBridgeViewModel

    init(viewModel: MovieBridgeViewModel = MovieBridgeViewModel()) {
        _viewModel = State(initialValue: viewModel)
    }

    var body: some View {
        NavigationStack {
            List(viewModel.movies) { movie in
                MovieRow(movie: movie)
            }
            .navigationTitle("MovieBridge")
            .overlay {
                if let errorMessage = viewModel.errorMessage {
                    ContentUnavailableView(
                        "Unable to Load Movies",
                        systemImage: "exclamationmark.triangle",
                        description: Text(errorMessage)
                    )
                } else if viewModel.movies.isEmpty {
                    ContentUnavailableView(
                        "No Movies",
                        systemImage: "film",
                        description: Text("The sample JSON has not been decoded yet.")
                    )
                }
            }
            .task {
                viewModel.load()
            }
        }
    }
}

private struct MovieRow: View {
    let movie: Movie

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(movie.title)
                .font(.headline)

            HStack {
                Text(movie.genre.rawValue)
                Text("•")
                Text(movie.releaseYear.map(String.init) ?? "Unknown year")
                Text("•")
                Text(String(format: "%.1f", movie.rating))
            }
            .font(.subheadline)
            .foregroundStyle(.secondary)

            if let runtime = movie.runtimeMinutes {
                Text("\(runtime) minutes • \(movie.language ?? "unknown")")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
        .padding(.vertical, 4)
    }
}

#Preview("Loaded") {
    ContentView(
        viewModel: MovieBridgeViewModel(
            dataService: MovieDataService()
        )
    )
}
