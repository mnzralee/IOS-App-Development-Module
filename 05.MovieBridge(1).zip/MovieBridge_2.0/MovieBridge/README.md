# MovieBridge 2.0 — Lecture 5 Demo

A small SwiftUI / Swift 6 teaching app for Lecture 5: **JSON, Codable & DTOs**.

## What it demonstrates

- reading JSON structure before writing Swift
- `Decodable` and compiler-synthesised decoding
- `JSONDecoder`
- `CodingKeys`
- nested DTOs and response envelopes
- DTOs versus domain models
- explicit DTO → domain mapping
- MVVM with modern Observation
- dependency injection without a singleton
- SwiftUI previews
- separate decoding/mapping test responsibility

## Architecture

```text
sample JSON
    ↓
MovieDataService
    ↓
MovieResponseDTO → [MovieDTO]
    ↓
MovieDTO.toDomain()
    ↓
[Movie]
    ↓
MovieBridgeViewModel
    ↓
SwiftUI View
```

The ViewModel works only with the domain model. It does not know JSON keys, `CodingKeys`, or `JSONDecoder`.

## Why there is no networking

Lecture 5 is about the **data boundary**. The sample data is local — `MovieDataService` loads `sample_movies.json` from the app bundle, the same file the slides walk through — so students can see decoding and mapping without introducing URLSession, networking errors, or async/await before those topics are taught.

## Suggested live demonstration

1. Open `sample_movies.json` and identify the response envelope.
2. Open `MovieDTO.swift` and match the JSON shape to Swift types.
3. Point at `CodingKeys` and explain the name translation.
4. Follow `MovieDTO.toDomain()` and identify where meaning changes.
5. Open `MovieBridgeViewModel.swift` and notice that it only receives `[Movie]` from the service.
6. Open `ContentView.swift` and show that the View never sees JSON or DTOs.
7. Run the tests and distinguish decoding from mapping responsibility — `MovieMappingTests.swift` has a decoding-only test, a mapping-only test, and a test that isolates the genre-priority rule, so a failure always points at one layer.

## Suggested student changes

- Add `overview` to the DTO and decide whether it belongs in the domain model.
- Add a domain-only property such as `ratingDescription`.
- Add another genre mapping rule.
- Add a nested API object and decide whether it belongs in the domain model.
- Break a `CodingKeys` entry and observe the decoding failure.
