import Observation

@MainActor
@Observable
final class MovieBridgeViewModel {
    private(set) var movies: [Movie] = []
    private(set) var errorMessage: String?

    private let dataService: MovieDataService

    init(dataService: MovieDataService = MovieDataService()) {
        self.dataService = dataService
    }

    func load() {
        errorMessage = nil

        do {
            movies = try dataService.loadMovies()
        } catch {
            movies = []
            errorMessage = String(describing: error)
        }
    }
}
