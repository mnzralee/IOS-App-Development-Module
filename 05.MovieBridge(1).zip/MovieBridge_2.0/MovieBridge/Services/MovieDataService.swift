import Foundation

enum MovieDataServiceError: Error, LocalizedError {
    case missingResource

    var errorDescription: String? {
        switch self {
        case .missingResource:
            return "Could not find sample_movies.json in the app bundle."
        }
    }
}

struct MovieDataService: Sendable {
    /// Loads the SAME bundled `sample_movies.json` the slides walk through —
    /// not an inline copy. If the file and the slides ever drift apart,
    /// this line is what forces someone to notice.
    func loadMovies() throws -> [Movie] {
        guard let url = Bundle.main.url(forResource: "sample_movies", withExtension: "json") else {
            throw MovieDataServiceError.missingResource
        }
        let data = try Data(contentsOf: url)
        let response = try JSONDecoder().decode(MovieResponseDTO.self, from: data)
        return response.results.map { $0.toDomain() }
    }
}
